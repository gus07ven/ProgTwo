package projectTwo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.StringTokenizer;

import javax.swing.JOptionPane;

public class GarageSaleImp extends DataManager implements IGarageSale {

	private String fileLocation;
	private String itemSer;
	private String fileName;
	private String itemDel;

	public static void main(String[] args) throws FileNotFoundException,
			IOException {
		GarageSale a2 = new GarageSale();
		GarageSaleImp b1 = new GarageSaleImp();
		// b1.read("C:\\Users\\Gustavo\\Documents\\workspace\\COSC 1437 - Programming II\\src\\projectTwo\\garageSale.txt");
		// b1.write("gs2.txt");
		// b1.read("garagaSale.txt");
		// b1.displayAllItems();
		// b1.searchItem("car");
		b1.deleteItem("car");
	}

	@Override
	public String searchItem(String itemSer) {
		FileReader fr = null;
		BufferedReader br = null;
		try {
			fr = new FileReader(
					new File(
							"C:\\Users\\Gustavo\\Documents\\workspace\\COSC 1437 - Programming II\\src\\projectTwo\\garageSale.txt"));
			br = new BufferedReader(fr);
			String line;
			while ((line = br.readLine()) != null) {
				String a = line;
				String b = itemSer;
				if (a.toLowerCase().contains(b.toLowerCase())) {
					System.out.println(a);
					JOptionPane.showMessageDialog(null,
							"The item has been printed to the console.");
				}
			}
			br.close();
			fr.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public String displayAllItems() {
		try {
			File file = new File(
					"C:\\Users\\Gustavo\\Documents\\workspace\\COSC 1437 - Programming II\\src\\projectTwo\\garageSale.txt");
			FileReader fr = new FileReader(file);
			BufferedReader br = new BufferedReader(fr);
			String line;
			while ((line = br.readLine()) != null) {
				StringTokenizer st = new StringTokenizer(line, ",", true);
				while (st.hasMoreTokens()) {
					line = st.nextToken();
					if (line.equals(",")) {
						break;
					} else {
						System.out.println(line);
					}
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public String addItemAndLocation(GarageSale a) throws IOException {
		FileWriter fwriter = new FileWriter(
				"C:\\Users\\Gustavo\\Documents\\workspace\\COSC 1437 - Programming II\\src\\projectTwo\\garageSale.txt",
				true);
		PrintWriter outputFile = new PrintWriter(fwriter);
		outputFile.println("\n" + a.getItem() + ", " + a.getLocation());
		outputFile.close();
		String result = "The item " + a.getItem() + " and location "
				+ a.getLocation() + " have been added";
		System.out.print(result);
		return result;
	}

	@Override
	public String deleteItem(String itemDel) {
		try {
			File inputFile = new File("C:\\Users\\Gustavo\\Documents\\workspace\\COSC 1437 - Programming II\\src\\projectTwo\\garageSale.txt");
			File tempFile = new File("myTempFile.txt");

			BufferedReader reader = new BufferedReader(new FileReader(inputFile));
			BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));

			String lineToRemove = itemDel;
			String currentLine;

			while((currentLine = reader.readLine()) != null) {
			    // trim newline when comparing with lineToRemove
			    String trimmedLine = currentLine.trim();
			    if(trimmedLine.equals(lineToRemove)) continue;
			    writer.write(currentLine + System.getProperty("line.separator"));
			}
			writer.close(); 
			reader.close(); 
			boolean successful = tempFile.renameTo(inputFile);
	} catch (FileNotFoundException e){
		e.printStackTrace();
	} catch (Exception e){
		e.printStackTrace();
	}
		return null;
	}

	@Override
	public String write(String fileName) {
		this.fileName = fileName;
		PrintWriter writer = null;
		try {
			FileWriter fw = new FileWriter(fileName, true);
			writer = new PrintWriter(fw);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		String add = JOptionPane
				.showInputDialog("Please type what you would like to add to the file.");
		writer.println("\n");
		writer.println(add);
		writer.close();
		String added = "The info was added to the file. Thank you!";
		return added;
	}

	@Override
	public String read(String fileLocation) {
		fileLocation = "C:\\Users\\Gustavo\\Documents\\workspace\\COSC 1437 - Programming II\\src\\projectTwo\\garageSale.txt";
		FileReader fr = null;
		BufferedReader br = null;

		try {
			fr = new FileReader(fileLocation);
			br = new BufferedReader(fr);
			String line;
			while ((line = br.readLine()) != null) {
				System.out.println(line);
			}
			br.close();
			fr.close();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		JOptionPane.showMessageDialog(null,
				"The file content printed in the console. Thanks!");
		return null;
	}
}

